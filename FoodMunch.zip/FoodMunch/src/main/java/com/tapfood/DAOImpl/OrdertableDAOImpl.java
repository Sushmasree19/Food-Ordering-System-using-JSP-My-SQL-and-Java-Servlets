package com.tapfood.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.tap.pro.Ordertable;
import com.tapfood.DAO.OrdertableDAO;
import com.tapfoods.DBUtills.DBUtills;

public class OrdertableDAOImpl implements OrdertableDAO {
	public int saveOrder(Ordertable order) {
        int orderId = 0;
        try {
            Connection con = DBUtills.myconnect();
            String query = "INSERT INTO Ordertable (restaurantId, userId, dateTime, totalAmount, status, paymentMode) VALUES (?, ?, now(), ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setInt(1, order.getRestaurantId());
            pst.setInt(2, order.getUserId());
            pst.setFloat(3, order.getTotalAmount());
            pst.setString(4, order.getStatus());
            pst.setString(5, order.getPaymentMode());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
            	
                var rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    orderId = rs.getInt(1);
                }
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderId;
    }

}
