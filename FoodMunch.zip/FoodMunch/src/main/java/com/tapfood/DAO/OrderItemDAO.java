package com.tapfood.DAO;

import com.tap.pro.OrderItem;

public interface OrderItemDAO {
	public void saveOrderItem(OrderItem orderItem);
}
