package com.tapfood.DAO;

import java.util.ArrayList;

import com.tap.pro.User;


public interface UserDAO {
	int adduser (User u);
	ArrayList<User> getAllUser();
	User getUser(String email,String password);
	int  updateUser(User u);
	int deleteUser(String email);
	
	

}
