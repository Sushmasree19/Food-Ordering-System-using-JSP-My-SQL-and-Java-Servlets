package com.tapfood.DAO;

import com.tap.pro.Ordertable;

public interface OrdertableDAO {
	public int saveOrder(Ordertable order);

}
